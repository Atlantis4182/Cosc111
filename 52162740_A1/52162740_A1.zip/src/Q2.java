
public class Q2 {

	public static void main(String[] args) {

		int w = 7;
		int h = 9;
		System.out.println("Perimeter of rectangle: " + ((2*w)+(2*h)));
		System.out.println("Area of rectangle: " + (w)*(h));
	}

}
