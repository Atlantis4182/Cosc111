
public class Q1 {

	public static void main(String[] args) {
		
		System.out.println("U   U   B B      C C");
		System.out.println("U   U   B   B  C");
		System.out.println("U   U   B B    C");
		System.out.println("U   U   B   B  C");
		System.out.println(" U U    B B      C C");
	}

}
