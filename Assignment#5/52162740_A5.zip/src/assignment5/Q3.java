package assignment5;

public class Q3 {
	public static void main(String[] args) {
		
		int min = 100;
		int max = 200;
		int counter = 0;
		for (min = 100; min <= max; min++) {
			int a = min%5;
			int b = min%6;
			if (a == 0 ^ b == 0) {
				System.out.printf("%d ",min);
				counter++;
				if (counter == 10) {
						System.out.println();
				counter = 0;
				}
					}
			
							
							}
							
					}
				

			
			}
			

		
		
	